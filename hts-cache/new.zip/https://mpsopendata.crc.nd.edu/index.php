<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" dir="ltr">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<base href="https://mpsopendata.crc.nd.edu/index.php" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="Kristina Davis" />
	<meta name="description" content="MPS Open Data Workshop website" />
	<meta name="generator" content="Joomla! - Open Source Content Management" />
	<title>MPSOpenData</title>
	<link href="/templates/mpsod-protostar/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
	<link href="https://mpsopendata.crc.nd.edu/index.php/component/search/?id=8&amp;Itemid=101&amp;format=opensearch" rel="search" title="Search MPSOpenData" type="application/opensearchdescription+xml" />
	<link href="/templates/mpsod-protostar/css/template.css" rel="stylesheet" type="text/css" />
	<script src="/media/jui/js/jquery.min.js?02acf84151265a5160a64b014bc8a49a" type="text/javascript"></script>
	<script src="/media/jui/js/jquery-noconflict.js?02acf84151265a5160a64b014bc8a49a" type="text/javascript"></script>
	<script src="/media/jui/js/jquery-migrate.min.js?02acf84151265a5160a64b014bc8a49a" type="text/javascript"></script>
	<script src="/media/system/js/caption.js?02acf84151265a5160a64b014bc8a49a" type="text/javascript"></script>
	<script src="/media/jui/js/bootstrap.min.js?02acf84151265a5160a64b014bc8a49a" type="text/javascript"></script>
	<script src="/templates/mpsod-protostar/js/template.js" type="text/javascript"></script>
	<!--[if lt IE 9]><script src="/media/system/js/html5fallback.js?02acf84151265a5160a64b014bc8a49a" type="text/javascript"></script><![endif]-->
	<script type="text/javascript">
jQuery(window).on('load',  function() {
				new JCaption('img.caption');
			});
	</script>

				<link href='//fonts.googleapis.com/css?family=Open+Sans:400,600,800' rel='stylesheet' type='text/css' />
		<style type="text/css">
			h1,h2,h3,h4,h5,h6,.site-title{
				font-family: 'Open Sans', sans-serif;
			}
		</style>
				<style type="text/css">
		body.site
		{
<!--			border-top: 3px solid #007ba6; -->
			background-color: #264e60		}
		a
		{
			color: #007ba6;
		}
		.navbar-inner, .nav-list > .active > a, .nav-list > .active > a:hover, .dropdown-menu li > a:hover, .dropdown-menu .active > a, .dropdown-menu .active > a:hover, .nav-pills > .active > a, .nav-pills > .active > a:hover,
		.btn-primary
		{
			background: #007ba6;
		}
		.navbar-inner
		{
			-moz-box-shadow: 0 1px 3px rgba(0, 0, 0, .25), inset 0 -1px 0 rgba(0, 0, 0, .1), inset 0 30px 10px rgba(0, 0, 0, .2);
			-webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, .25), inset 0 -1px 0 rgba(0, 0, 0, .1), inset 0 30px 10px rgba(0, 0, 0, .2);
			box-shadow: 0 1px 3px rgba(0, 0, 0, .25), inset 0 -1px 0 rgba(0, 0, 0, .1), inset 0 30px 10px rgba(0, 0, 0, .2);
		}
	</style>
		<!--[if lt IE 9]>
		<script src="/media/jui/js/html5.js"></script>
	<![endif]-->
</head>

<body class="site com_content view-article no-layout no-task itemid-101">

	<!-- Body -->
	<div class="body">
		<div class="container">
			<!-- Header -->
			<header class="header" role="banner">
				<div class="header-inner clearfix">
					<a class="brand pull-left" href="/">
						<img src="https://mpsopendata.crc.nd.edu/images/mpsod-visual-id/mpsopendata_logo_dkbkgrnd.png" width="250px" />											</a>
					<div class="header-search pull-right">
						<div class="search">
	<form action="/index.php" method="post" class="form-inline" role="search">
		<label for="mod-search-searchword91" class="element-invisible">Search ...</label> <input name="searchword" id="mod-search-searchword91" maxlength="200"  class="inputbox search-query input-medium" type="search" placeholder="Search MPS Open Data" />		<input type="hidden" name="task" value="search" />
		<input type="hidden" name="option" value="com_search" />
		<input type="hidden" name="Itemid" value="101" />
	</form>
</div>

					</div>
				</div>
			</header>
          <div class="shadow-box">
							<nav class="navigation" role="navigation">
					<div class="navbar pull-left">
						<a class="btn btn-navbar collapsed" data-toggle="collapse" data-target=".nav-collapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</a>
					</div>
					<div class="nav-collapse">
						<ul class="nav menu nav-plain mod-list">
<li class="item-101 default current active"><a href="/index.php" >MPSOpenData</a></li><li class="item-112"><a href="/index.php/final-report" >FINAL Report</a></li><li class="item-103 parent"><a href="/index.php/workshop-1/about-w1" >Workshop 1</a></li><li class="item-115 parent"><a href="/index.php/w-2/about-w2" >Workshop 2</a></li><li class="item-111"><a href="/index.php/reference-reading-materials" >Reference Reading Materials</a></li></ul>

					</div>
				</nav>
						
			<div class="row-fluid">
									<!-- Begin Sidebar -->
					<div id="sidebar" class="span3">
						<div class="sidebar-nav">
									<div class="moduletable">
						

<div class="custom"  >
	<h6 class="workshop-label"><a href="/index.php/w-2/about-w2">Workshop 2</a></h6>
<h3 class="workshop-title"><a style="color: #333333;" href="/index.php/w-2/about-w2">Gauging the Impact of Requirements for Public Access to Data</a></h3>
<h2 class="workshop-label">Dec 1-2, 2016</h2>
<h3 class="workshop-title">Arlington, VA</h3></div>
		</div>
	
						</div>
					</div>
					<!-- End Sidebar -->
								<main id="content" role="main" class="span9">
					<!-- Begin Content -->
					
					<div id="system-message-container">
	</div>

					<div class="item-page" itemscope itemtype="https://schema.org/Article">
	<meta itemprop="inLanguage" content="en-GB" />
	
		
						
		
	
	
		
								<div itemprop="articleBody">
		<h1 style="margin-bottom: 0;">MPS Open Data Workshop Series</h1>
<h3 style="color: #709900; margin-top: 0; margin-bottom: 20px;">Taking the pulse of the research community on open data issues</h3>
<p>Funded by the National Science Foundation, this workshop series will generate discipline-specific responses from the <span style="font-weight: 600;">Mathematical and Physical Sciences</span> research communities to the federal policy requiring open data and the recently-released NSF policy statement on open data.</p>
<p>In order to decide how and what to preserve for public consumption, and in what manner the data will be stored and accessed, a series of dialogues is required. Discussions within individual disciplines must reach a consensus on data preservation procedures and data access guidelines consistent with discipline-specific expectations for data re-use, access policies, and the level of burden implied by conservation that is placed on the individual investigator.</p>
<p>These workshops are designed to “<span style="font-style: italic;">take the pulse</span>” of the research community on these issues. A final report containing suggestions for best practice and implementation will be submitted to the NSF upon completion of the workshop series.</p> 	</div>

	
							</div>

					

<div class="custom"  >
	<div class="nsf-logo">
<p><img src="/images/mpsod-visual-id/nsf4.png" alt="NSF logo" /></p>
<p class="nsf-attribution">The MPS Open Data workshop series is supported by the National Science Foundation.</p>
</div></div>

					<!-- End Content -->
				</main>
							</div> <!-- Closer row-fluid -->
            <div class="logo-full-detail"> </div>
          </div>  <!-- Close shadow-box -->
		</div>  <!-- Close container -->
	</div> <!-- Close Body -->
	<!-- Footer -->
	<footer class="footer" role="contentinfo">
		<div class="container">
			
			<p class="pull-right">
				<a href="#top" id="back-top">
					Back to Top				</a>
			</p>
			<p>
				&copy; 2024 MPSOpenData			</p>
		</div>
	</footer>
	
</body>
</html>
